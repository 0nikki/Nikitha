aws cloudformation delete-stack \
--stack-name $1